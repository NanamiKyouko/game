package sweeper;

public enum StatusUpperField {
    OPENED,
    CLOSED,
    FLAGGED;
}
